package http://hl7.org/fhir/us/core/ImplementationGuide/hl7.fhir.us.core.r4validator-0.0.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class USCoreEncounterProfile {

}
